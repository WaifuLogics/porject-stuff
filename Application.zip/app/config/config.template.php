<?php
$GLOBALS['config'] = [
    'database' => [
        'servername' => '',
        'username' => '',
        'password' => '',
        'dbname' => ''
    ],
    'twig' => [
        'cache' => false
    ],
    'mail' => [
        'host' => '',
        'protocol' => '',
        'port' => 587,
        'username' => '',
        'pass' => '',
        'hostname' => '',
    ]
];