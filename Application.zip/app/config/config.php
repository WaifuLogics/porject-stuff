<?php
$GLOBALS['config'] = [
    'database' => [
        'servername' => /*"protask.duncte123.me"*/ 'localhost',
        'username' => /*"pro"*/ 'root',
        'password' => /*"30Fos5L1Y"*/ '',
        'dbname' => "it_connection"
    ],
    'twig' => [
        'cache' => false
    ]
];
