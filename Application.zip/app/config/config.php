<?php
$GLOBALS['config'] = [
    'database' => [
        'servername' => 'localhost',
        'username' => 'root',
        'password' => '',
        'dbname' => "it_connection"
    ],
    'twig' => [
        'cache' => false
    ]
];
