Command To run app: php -S 127.0.0.1:8080
Database = database\it_connection_v0.0.12.sql